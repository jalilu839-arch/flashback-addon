package dev.flashguiplus;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Settings shown in the "FlashGUI+" section of Flashback's Visuals window. */
public class FlashGuiConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static FlashGuiConfig instance = new FlashGuiConfig();

    public boolean recordedGui = true;       // show the recorded GUI during playback / export
    public boolean dimBehind = true;         // darkened + blurred background behind the GUI
    public boolean recordedCursor = true;    // use the recorded mouse position (hover, tooltips)
    public boolean showMousePointer = true;  // draw a pointer where the mouse was
    public boolean hitboxes = false;         // F3+B style hitboxes in the replay
    public boolean debugScreen = false;      // F3 overlay in the replay
    public boolean recordGuis = true;        // write GUIs into new recordings

    public static FlashGuiConfig get() { return instance; }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("flashguiplus.json");
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                FlashGuiConfig c = GSON.fromJson(Files.readString(p), FlashGuiConfig.class);
                if (c != null) instance = c;
            }
        } catch (Exception e) {
            FlashGuiPlus.LOGGER.warn("Could not read config", e);
        }
    }

    public static void save() {
        try {
            Files.writeString(path(), GSON.toJson(instance));
        } catch (Exception e) {
            FlashGuiPlus.LOGGER.warn("Could not save config", e);
        }
    }
}
