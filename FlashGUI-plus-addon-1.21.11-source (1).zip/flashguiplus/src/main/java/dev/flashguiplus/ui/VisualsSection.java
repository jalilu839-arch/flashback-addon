package dev.flashguiplus.ui;

import com.moulberry.flashback.editor.ui.ImGuiHelper;
import dev.flashguiplus.FlashGuiConfig;
import dev.flashguiplus.util.DebugToggles;
import imgui.moulberry90.ImGui;

/** The "FlashGUI+" block inside Flashback's Visuals window (between "GUI" and "World"). */
public final class VisualsSection {
    private VisualsSection() {}

    public static void render() {
        FlashGuiConfig c = FlashGuiConfig.get();
        boolean dirty = false;

        ImGuiHelper.separatorWithText("FlashGUI+");

        if (ImGui.checkbox("Recorded GUI##fgp", c.recordedGui)) { c.recordedGui = !c.recordedGui; dirty = true; }
        ImGuiHelper.tooltip("Show the chest / inventory / crafting screen the player had open, with the items where they were.");

        if (ImGui.checkbox("Dim behind GUI##fgp", c.dimBehind)) { c.dimBehind = !c.dimBehind; dirty = true; }
        ImGuiHelper.tooltip("Draw the usual darkened, blurred background behind the GUI.");

        if (ImGui.checkbox("Recorded cursor##fgp", c.recordedCursor)) { c.recordedCursor = !c.recordedCursor; dirty = true; }
        ImGuiHelper.tooltip("Hover slots and show item tooltips where the player's mouse was.");

        if (ImGui.checkbox("Show mouse pointer##fgp", c.showMousePointer)) { c.showMousePointer = !c.showMousePointer; dirty = true; }
        ImGuiHelper.tooltip("Draw the mouse pointer itself where the player's mouse was.");

        if (ImGui.checkbox("Hitboxes##fgp", c.hitboxes)) {
            c.hitboxes = !c.hitboxes; dirty = true; DebugToggles.setHitboxes(c.hitboxes);
        }
        ImGuiHelper.tooltip("Draw entity hitboxes, eye lines and look vectors (the same view as F3 + B).");

        if (ImGui.checkbox("Debug screen (F3)##fgp", c.debugScreen)) {
            c.debugScreen = !c.debugScreen; dirty = true; DebugToggles.setDebugScreen(c.debugScreen);
        }
        ImGuiHelper.tooltip("Show the F3 debug screen in the replay.");

        if (ImGui.checkbox("Record GUIs##fgp", c.recordGuis)) { c.recordGuis = !c.recordGuis; dirty = true; }
        ImGuiHelper.tooltip("Write the GUIs you open into new recordings (applies to the next/current recording).");

        if (dirty) FlashGuiConfig.save();
    }
}
