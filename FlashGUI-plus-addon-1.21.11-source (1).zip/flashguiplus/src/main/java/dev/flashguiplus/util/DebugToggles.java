package dev.flashguiplus.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.debug.DebugScreenEntries;
import net.minecraft.client.gui.components.debug.DebugScreenEntryList;
import net.minecraft.client.gui.components.debug.DebugScreenEntryStatus;

/**
 * F3 / F3+B in 1.21.9+ go through Minecraft#debugEntries.
 * This is the LEAST verified file: if the compiler complains about a name here, fix it using the F3+B code
 * in KeyboardHandler (or empty the two methods - the rest of the addon does not depend on them).
 */
public final class DebugToggles {
    private DebugToggles() {}

    public static void setHitboxes(boolean on) {
        DebugScreenEntryList list = Minecraft.getInstance().debugEntries;
        list.setStatus(DebugScreenEntries.ENTITY_HITBOXES,
                on ? DebugScreenEntryStatus.ALWAYS_ON : DebugScreenEntryStatus.NEVER);
    }

    public static void setDebugScreen(boolean on) {
        DebugScreenEntryList list = Minecraft.getInstance().debugEntries;
        if (list.isOverlayVisible() != on) list.toggleF3Visible();
    }
}
