package dev.flashguiplus.record;

import com.moulberry.flashback.Flashback;
import com.moulberry.flashback.record.Recorder;
import com.mojang.serialization.DataResult;
import dev.flashguiplus.FlashGuiConfig;
import dev.flashguiplus.FlashGuiPlus;
import dev.flashguiplus.mixin.AbstractCommandBlockEditScreenAccessor;
import dev.flashguiplus.mixin.AbstractContainerScreenAccessor;
import dev.flashguiplus.mixin.CommandBlockEditScreenAccessor;
import dev.flashguiplus.net.GuiBody;
import dev.flashguiplus.net.GuiBody.CommandBlockBody;
import dev.flashguiplus.net.GuiBody.ContainerBody;
import dev.flashguiplus.net.GuiBody.DialogBody;
import dev.flashguiplus.net.GuiBody.SlotInfo;
import dev.flashguiplus.net.GuiStatePayload;
import dev.flashguiplus.net.GuiStatePayload.Op;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.dialog.DialogScreen;
import net.minecraft.client.gui.screens.inventory.AbstractCommandBlockEditScreen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.CommandBlockEditScreen;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import net.minecraft.network.ConnectionProtocol;
import net.minecraft.network.protocol.common.ClientboundCustomPayloadPacket;
import net.minecraft.resources.RegistryOps;
import net.minecraft.server.dialog.Dialog;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.level.block.entity.CommandBlockEntity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/** Runs every client tick while Flashback is recording and writes the open GUI into the replay. */
public final class GuiRecorder {
    /** Set by MixinClientCommonPacketListenerImpl when the server shows a 1.21.6+ dialog. */
    public static volatile Holder<Dialog> lastDialog;

    private static byte[] lastBytes;
    private static int stateId;
    private static int sinceFull;
    private static boolean open;

    private GuiRecorder() {}

    public static void tick(Minecraft mc) {
        Recorder rec = Flashback.RECORDER;
        if (rec == null || Flashback.isInReplay() || mc.level == null) {
            reset();
            return;
        }
        if (rec.isPaused()) return;

        GuiBody body = null;
        if (FlashGuiConfig.get().recordGuis) {
            try {
                body = capture(mc, mc.screen);
            } catch (Throwable t) {
                FlashGuiPlus.LOGGER.warn("Could not capture GUI {}", mc.screen, t);
            }
        }

        if (body == null) {
            if (open) {
                send(rec, new GuiStatePayload(Op.CLOSE, stateId, 0, 0, 0, 0, null));
                open = false;
                lastBytes = null;
            }
            return;
        }

        int gw = mc.getWindow().getGuiScaledWidth();
        int gh = mc.getWindow().getGuiScaledHeight();
        float mx = (float) (mc.mouseHandler.xpos() * gw / mc.getWindow().getScreenWidth());
        float my = (float) (mc.mouseHandler.ypos() * gh / mc.getWindow().getScreenHeight());

        byte[] bytes = GuiBody.toBytes(body, mc.level.registryAccess());
        boolean changed = lastBytes == null || !Arrays.equals(bytes, lastBytes);
        if (changed) stateId++;

        if (changed || !open || ++sinceFull >= 10) {
            sinceFull = 0;
            send(rec, new GuiStatePayload(Op.STATE, stateId, gw, gh, mx, my, body));
        } else {
            send(rec, new GuiStatePayload(Op.CURSOR, stateId, gw, gh, mx, my, null));
        }
        lastBytes = bytes;
        open = true;
    }

    private static void reset() {
        lastBytes = null;
        open = false;
        sinceFull = 0;
    }

    private static void send(Recorder rec, GuiStatePayload payload) {
        rec.writePacketAsync(new ClientboundCustomPayloadPacket(payload), ConnectionProtocol.PLAY);
    }

    // ------------------------------------------------------------------ capture

    @SuppressWarnings("rawtypes")
    private static GuiBody capture(Minecraft mc, Screen screen) {
        if (screen == null) return null;
        if (screen instanceof AbstractContainerScreen<?> acs) return captureContainer(acs);
        if (screen instanceof CommandBlockEditScreen cb) return captureCommandBlock(cb);
        if (screen instanceof DialogScreen) return captureDialog(mc);
        return null; // add more GUIs here (sign, book, anvil rename box, ...)
    }

    private static GuiBody captureContainer(AbstractContainerScreen<?> screen) {
        AbstractContainerMenu menu = screen.getMenu();
        boolean playerInv = menu instanceof InventoryMenu;
        String type = "";
        if (!playerInv) {
            try {
                var key = BuiltInRegistries.MENU.getKey(menu.getType());
                if (key != null) type = key.toString();
            } catch (Throwable ignored) {
                // creative inventory etc. have no menu type -> generic slot renderer on playback
            }
        }
        AbstractContainerScreenAccessor a = (AbstractContainerScreenAccessor) screen;
        List<SlotInfo> slots = new ArrayList<>(menu.slots.size());
        for (Slot s : menu.slots) slots.add(new SlotInfo(s.x, s.y, s.getItem().copy()));
        return new ContainerBody(playerInv, type, menu.containerId, screen.getTitle(),
                a.flashguiplus$leftPos(), a.flashguiplus$topPos(),
                a.flashguiplus$imageWidth(), a.flashguiplus$imageHeight(),
                slots, menu.getCarried().copy());
    }

    private static GuiBody captureCommandBlock(CommandBlockEditScreen screen) {
        String command = ((AbstractCommandBlockEditScreenAccessor) screen).flashguiplus$commandEdit().getValue();
        CommandBlockEditScreenAccessor a = (CommandBlockEditScreenAccessor) screen;
        CommandBlockEntity.Mode mode = a.flashguiplus$mode();
        int m = mode == CommandBlockEntity.Mode.SEQUENCE ? 0 : mode == CommandBlockEntity.Mode.AUTO ? 1 : 2;
        return new CommandBlockBody(command, m, a.flashguiplus$conditional(), a.flashguiplus$autoexec());
    }

    private static GuiBody captureDialog(Minecraft mc) {
        Holder<Dialog> dialog = lastDialog;
        if (dialog == null || mc.getConnection() == null) return null;
        RegistryOps<Tag> ops = RegistryOps.create(NbtOps.INSTANCE, mc.getConnection().registryAccess());
        DataResult<Tag> result = Dialog.CODEC.encodeStart(ops, dialog);
        Optional<Tag> tag = result.result();
        return tag.<GuiBody>map(DialogBody::new).orElse(null);
    }
}
