package dev.flashguiplus.playback;

import com.moulberry.flashback.Flashback;
import com.moulberry.flashback.playback.ReplayServer;
import dev.flashguiplus.FlashGuiConfig;
import dev.flashguiplus.FlashGuiPlus;
import dev.flashguiplus.net.GuiStatePayload;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;

/** Receives recorded GUI packets during playback / export and draws the GUI on top of the replay. */
public final class GuiPlayback {
    /** A state is valid for this many replay ticks after its last packet (full state is re-sent every 10). */
    private static final int TTL_TICKS = 15;

    private static GuiStatePayload state;   // last full STATE
    private static float mx, my;
    private static int guiW, guiH;
    private static int lastTick;

    private static GhostScreens.Ghost ghost;
    private static boolean rendering;
    private static boolean failedOnce;

    private GuiPlayback() {}

    /** True while we are drawing a ghost screen (used by MixinScreen to skip the dim if the user turned it off). */
    public static boolean isRenderingGhost() { return rendering; }

    public static void accept(GuiStatePayload p) {
        if (!Flashback.isInReplay()) return;
        switch (p.op()) {
            case CLOSE -> clear();
            case STATE -> {
                state = p;
                mx = p.mx(); my = p.my(); guiW = p.guiW(); guiH = p.guiH();
                lastTick = replayTick();
                GhostScreens.Ghost g = GhostScreens.build(ghost, p.body());
                ghost = g;
                failedOnce = false;
            }
            case CURSOR -> {
                if (state != null && state.stateId() == p.stateId()) {
                    mx = p.mx(); my = p.my();
                    lastTick = replayTick();
                }
            }
        }
    }

    public static void clear() {
        state = null;
        ghost = null;
    }

    private static int replayTick() {
        ReplayServer rs = Flashback.getReplayServer();
        return rs == null ? 0 : rs.getReplayTick();
    }

    /** Fabric HudElement callback. */
    public static void render(GuiGraphics graphics, DeltaTracker tracker) {
        FlashGuiConfig cfg = FlashGuiConfig.get();
        if (!cfg.recordedGui || state == null || ghost == null || failedOnce) return;
        if (!Flashback.isInReplay()) return;

        // seeking / paused-then-scrubbed: drop stale state
        if (Math.abs(replayTick() - lastTick) > TTL_TICKS) {
            clear();
            return;
        }

        Minecraft mc = Minecraft.getInstance();
        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();

        // screens are centered, so keep the recorded mouse offset from the centre
        int sx = Math.round(w / 2f + (mx - guiW / 2f));
        int sy = Math.round(h / 2f + (my - guiH / 2f));
        int hx = cfg.recordedCursor ? sx : -10000;
        int hy = cfg.recordedCursor ? sy : -10000;

        try {
            rendering = true;
            Screen screen = ghost.screen();
            ghost.ensureSize(mc, w, h);
            screen.render(graphics, hx, hy, tracker.getGameTimeDeltaPartialTick(false));
            if (cfg.showMousePointer) drawPointer(graphics, sx, sy);
        } catch (Throwable t) {
            failedOnce = true;
            FlashGuiPlus.LOGGER.warn("Could not render recorded GUI", t);
        } finally {
            rendering = false;
        }
    }

    private static void drawPointer(GuiGraphics g, int x, int y) {
        // 12-row arrow, black outline + white fill
        for (int pass = 0; pass < 2; pass++) {
            int color = pass == 0 ? 0xFF000000 : 0xFFFFFFFF;
            int o = pass == 0 ? 1 : 0;
            for (int r = 0; r < 12; r++) {
                int width = r < 9 ? r + 1 : 3;
                int left = r < 9 ? 0 : 2;
                g.fill(x + left - o, y + r - o, x + left + width + o, y + r + 1 + o, color);
            }
        }
    }
}
