package dev.flashguiplus.playback;

import dev.flashguiplus.FlashGuiPlus;
import dev.flashguiplus.net.GuiBody;
import dev.flashguiplus.net.GuiBody.CommandBlockBody;
import dev.flashguiplus.net.GuiBody.ContainerBody;
import dev.flashguiplus.net.GuiBody.DialogBody;
import dev.flashguiplus.net.GuiBody.SlotInfo;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.dialog.DialogConnectionAccess;
import net.minecraft.client.gui.screens.dialog.DialogScreens;
import net.minecraft.client.gui.screens.inventory.CommandBlockEditScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.NbtOps;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.RegistryOps;
import net.minecraft.server.ServerLinks;
import net.minecraft.server.dialog.Dialog;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CommandBlock;
import net.minecraft.world.level.block.entity.CommandBlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.lang.reflect.Proxy;
import java.util.Optional;

/**
 * Builds REAL vanilla screens (never opened, never given input) filled with the recorded data,
 * so replayed GUIs look exactly like the game's own.
 */
public final class GhostScreens {
    private GhostScreens() {}

    public static final class Ghost {
        private final String shapeKey;
        private final Screen screen;
        private final AbstractContainerMenu menu; // null for non-container GUIs
        private int w = -1, h = -1;

        Ghost(String shapeKey, Screen screen, AbstractContainerMenu menu) {
            this.shapeKey = shapeKey; this.screen = screen; this.menu = menu;
        }

        public Screen screen() { return screen; }

        public void ensureSize(Minecraft mc, int width, int height) {
            if (w != width || h != height) {
                screen.init(mc, width, height);
                w = width; h = height;
            }
        }
    }

    /** Reuses {@code previous} when only the contents changed. */
    public static Ghost build(Ghost previous, GuiBody body) {
        if (body == null) return null;
        Minecraft mc = Minecraft.getInstance();
        try {
            if (previous != null && previous.shapeKey.equals(body.shapeKey()) && body instanceof ContainerBody cb) {
                fill(previous, cb);
                return previous;
            }
            Ghost g = switch (body) {
                case ContainerBody cb -> buildContainer(mc, cb);
                case CommandBlockBody cb -> buildCommandBlock(cb);
                case DialogBody db -> buildDialog(mc, db);
            };
            if (g != null && body instanceof ContainerBody cb) fill(g, cb);
            return g;
        } catch (Throwable t) {
            FlashGuiPlus.LOGGER.warn("Could not rebuild recorded GUI", t);
            return null;
        }
    }

    // ---------------------------------------------------------------- containers

    private static RemotePlayer ghostPlayer;

    private static RemotePlayer ghostPlayer(Minecraft mc) {
        if (ghostPlayer == null || ghostPlayer.level() != mc.level) {
            ghostPlayer = new RemotePlayer(mc.level, mc.player.getGameProfile());
        }
        return ghostPlayer;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static Ghost buildContainer(Minecraft mc, ContainerBody b) {
        String key = b.shapeKey();
        try {
            RemotePlayer p = ghostPlayer(mc); // own inventory, so we never touch the real/replay player's
            if (b.playerInventory()) {
                return new Ghost(key, new InventoryScreen(p), p.inventoryMenu);
            }
            Identifier id = Identifier.tryParse(b.menuType());
            if (id != null && !b.menuType().isEmpty()) {
                MenuType type = BuiltInRegistries.MENU.getValue(id);
                if (type != null) {
                    Inventory inv = p.getInventory();
                    AbstractContainerMenu menu = type.create(b.containerId(), inv);
                    MenuScreens.ScreenConstructor ctor = MenuScreens.getConstructor(type); // via access widener
                    if (ctor != null) {
                        Screen screen = (Screen) ctor.create(menu, inv, b.title());
                        return new Ghost(key, screen, menu);
                    }
                }
            }
        } catch (Throwable t) {
            FlashGuiPlus.LOGGER.warn("Vanilla screen for {} failed, using generic one", b.menuType(), t);
        }
        return new Ghost(key, new FallbackContainerScreen(b), null);
    }

    private static void fill(Ghost g, ContainerBody b) {
        if (g.screen instanceof FallbackContainerScreen f) {
            f.update(b);
            return;
        }
        AbstractContainerMenu menu = g.menu;
        if (menu == null) return;
        int n = Math.min(menu.slots.size(), b.slots().size());
        for (int i = 0; i < n; i++) {
            SlotInfo s = b.slots().get(i);
            menu.setItem(i, 0, s.stack().copy());
        }
        menu.setCarried(b.carried().copy());
    }

    // ---------------------------------------------------------------- command block

    private static Ghost buildCommandBlock(CommandBlockBody b) {
        var block = switch (b.mode()) {
            case 0 -> Blocks.CHAIN_COMMAND_BLOCK;
            case 1 -> Blocks.REPEATING_COMMAND_BLOCK;
            default -> Blocks.COMMAND_BLOCK;
        };
        BlockState state = block.defaultBlockState().setValue(CommandBlock.CONDITIONAL, b.conditional());
        CommandBlockEntity be = new CommandBlockEntity(BlockPos.ZERO, state);
        be.setAutomatic(b.automatic());
        be.getCommandBlock().setCommand(b.command());
        return new Ghost(b.shapeKey(), new CommandBlockEditScreen(be), null);
    }

    // ---------------------------------------------------------------- 1.21.6+ dialogs

    private static Ghost buildDialog(Minecraft mc, DialogBody b) {
        RegistryOps<net.minecraft.nbt.Tag> ops =
                RegistryOps.create(NbtOps.INSTANCE, mc.getConnection().registryAccess());
        Optional<Holder<Dialog>> holder = Dialog.CODEC.parse(ops, b.dialogTag()).result();
        if (holder.isEmpty()) return null;

        // DialogScreens wants a "connection access" for button actions. Ghosts never receive clicks,
        // so a do-nothing proxy keeps this independent of the exact interface shape.
        Class<?> accessType = DialogConnectionAccess.class;
        Object access = Proxy.newProxyInstance(accessType.getClassLoader(), new Class<?>[]{accessType},
                (proxy, method, args) -> {
                    Class<?> r = method.getReturnType();
                    if (r == Optional.class) return Optional.empty();
                    if (r == ServerLinks.class) return ServerLinks.EMPTY;
                    if (r == boolean.class) return false;
                    if (r == int.class) return 0;
                    return null;
                });
        Screen screen = DialogScreens.createFromData(holder.get().value(), null,
                (DialogConnectionAccess) access);
        return new Ghost(b.shapeKey(), screen, null);
    }
}
