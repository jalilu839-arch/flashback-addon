package dev.flashguiplus.playback;

import dev.flashguiplus.net.GuiBody.ContainerBody;
import dev.flashguiplus.net.GuiBody.SlotInfo;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.world.item.ItemStack;

/** Generic panel + slots, used when a container has no vanilla screen we can rebuild (creative, modded, ...). */
public class FallbackContainerScreen extends Screen {
    private ContainerBody body;

    public FallbackContainerScreen(ContainerBody body) {
        super(body.title());
        this.body = body;
    }

    public void update(ContainerBody body) { this.body = body; }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        int l = (this.width - body.imageWidth()) / 2;
        int t = (this.height - body.imageHeight()) / 2;
        int r = l + body.imageWidth(), b = t + body.imageHeight();

        g.fill(l, t, r, b, 0xFFC6C6C6);
        g.fill(l, t, r, t + 2, 0xFFFFFFFF);
        g.fill(l, t, l + 2, b, 0xFFFFFFFF);
        g.fill(l, b - 2, r, b, 0xFF555555);
        g.fill(r - 2, t, r, b, 0xFF555555);
        g.drawString(this.font, body.title(), l + 8, t + 6, 0xFF404040, false);

        ItemStack hovered = ItemStack.EMPTY;
        for (SlotInfo s : body.slots()) {
            int x = l + s.x(), y = t + s.y();
            g.fill(x - 1, y - 1, x + 17, y + 17, 0xFF8B8B8B);
            g.fill(x, y, x + 16, y + 16, 0xFF373737);
            if (!s.stack().isEmpty()) {
                g.renderItem(s.stack(), x, y);
                g.renderItemDecorations(this.font, s.stack(), x, y);
            }
            if (mouseX >= x && mouseX < x + 16 && mouseY >= y && mouseY < y + 16) {
                g.fill(x, y, x + 16, y + 16, 0x80FFFFFF);
                hovered = s.stack();
            }
        }
        if (!body.carried().isEmpty()) {
            g.renderItem(body.carried(), mouseX - 8, mouseY - 8);
            g.renderItemDecorations(this.font, body.carried(), mouseX - 8, mouseY - 8);
        }
        if (!hovered.isEmpty() && body.carried().isEmpty()) {
            g.setTooltipForNextFrame(this.font, hovered, mouseX, mouseY);
        }
    }
}
