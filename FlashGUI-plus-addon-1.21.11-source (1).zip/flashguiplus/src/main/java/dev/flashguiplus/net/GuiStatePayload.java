package dev.flashguiplus.net;

import dev.flashguiplus.FlashGuiPlus;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/**
 * One packet in the replay file.
 *  STATE  = full GUI contents (sent on change and every 10 ticks so seeking recovers quickly)
 *  CURSOR = only the mouse moved
 *  CLOSE  = the GUI was closed
 */
public record GuiStatePayload(Op op, int stateId, int guiW, int guiH, float mx, float my, GuiBody body)
        implements CustomPacketPayload {

    public enum Op { CLOSE, STATE, CURSOR }

    public static final Type<GuiStatePayload> TYPE = new Type<>(FlashGuiPlus.id("gui_state"));
    public static final StreamCodec<RegistryFriendlyByteBuf, GuiStatePayload> CODEC =
            StreamCodec.of(GuiStatePayload::write, GuiStatePayload::read);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    private static void write(RegistryFriendlyByteBuf buf, GuiStatePayload p) {
        buf.writeByte(p.op.ordinal());
        buf.writeVarInt(p.stateId);
        buf.writeVarInt(p.guiW);
        buf.writeVarInt(p.guiH);
        buf.writeFloat(p.mx);
        buf.writeFloat(p.my);
        if (p.op == Op.STATE) {
            buf.writeByte(p.body.type());
            p.body.write(buf);
        }
    }

    private static GuiStatePayload read(RegistryFriendlyByteBuf buf) {
        Op op = Op.values()[buf.readByte()];
        int id = buf.readVarInt(), w = buf.readVarInt(), h = buf.readVarInt();
        float mx = buf.readFloat(), my = buf.readFloat();
        GuiBody body = null;
        if (op == Op.STATE) {
            int type = buf.readByte();
            body = GuiBody.read(type, buf);
        }
        return new GuiStatePayload(op, id, w, h, mx, my, body);
    }
}
