package dev.flashguiplus.net;

import io.netty.buffer.Unpooled;
import net.minecraft.core.RegistryAccess;
import net.minecraft.nbt.Tag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/** What a recorded GUI contains. Add a new record + a case in {@link #read} to support another GUI. */
public sealed interface GuiBody {
    int TYPE_CONTAINER = 0, TYPE_COMMAND_BLOCK = 1, TYPE_DIALOG = 2;

    int type();
    void write(RegistryFriendlyByteBuf buf);
    /** Same key = the ghost screen can be reused and only updated. */
    String shapeKey();

    static GuiBody read(int type, RegistryFriendlyByteBuf buf) {
        return switch (type) {
            case TYPE_CONTAINER -> ContainerBody.read(buf);
            case TYPE_COMMAND_BLOCK -> CommandBlockBody.read(buf);
            case TYPE_DIALOG -> DialogBody.read(buf);
            default -> throw new IllegalStateException("Unknown FlashGUI+ body type " + type);
        };
    }

    static byte[] toBytes(GuiBody body, RegistryAccess access) {
        RegistryFriendlyByteBuf buf = new RegistryFriendlyByteBuf(Unpooled.buffer(), access);
        try {
            body.write(buf);
            byte[] out = new byte[buf.readableBytes()];
            buf.readBytes(out);
            return out;
        } finally {
            buf.release();
        }
    }

    // ---------------------------------------------------------------- chests, inventory, crafting, furnace...
    record SlotInfo(int x, int y, ItemStack stack) {}

    record ContainerBody(boolean playerInventory, String menuType, int containerId, Component title,
                         int leftPos, int topPos, int imageWidth, int imageHeight,
                         List<SlotInfo> slots, ItemStack carried) implements GuiBody {
        public int type() { return TYPE_CONTAINER; }

        public String shapeKey() {
            return "c|" + playerInventory + "|" + menuType + "|" + title.getString() + "|" + slots.size();
        }

        public void write(RegistryFriendlyByteBuf buf) {
            buf.writeBoolean(playerInventory);
            buf.writeUtf(menuType);
            buf.writeVarInt(containerId);
            ComponentSerialization.STREAM_CODEC.encode(buf, title);
            buf.writeVarInt(leftPos); buf.writeVarInt(topPos);
            buf.writeVarInt(imageWidth); buf.writeVarInt(imageHeight);
            buf.writeVarInt(slots.size());
            for (SlotInfo s : slots) {
                buf.writeShort(s.x()); buf.writeShort(s.y());
                ItemStack.OPTIONAL_STREAM_CODEC.encode(buf, s.stack());
            }
            ItemStack.OPTIONAL_STREAM_CODEC.encode(buf, carried);
        }

        static ContainerBody read(RegistryFriendlyByteBuf buf) {
            boolean inv = buf.readBoolean();
            String type = buf.readUtf();
            int id = buf.readVarInt();
            Component title = ComponentSerialization.STREAM_CODEC.decode(buf);
            int l = buf.readVarInt(), t = buf.readVarInt(), w = buf.readVarInt(), h = buf.readVarInt();
            int n = buf.readVarInt();
            List<SlotInfo> slots = new ArrayList<>(n);
            for (int i = 0; i < n; i++) {
                int x = buf.readShort(), y = buf.readShort();
                slots.add(new SlotInfo(x, y, ItemStack.OPTIONAL_STREAM_CODEC.decode(buf)));
            }
            ItemStack carried = ItemStack.OPTIONAL_STREAM_CODEC.decode(buf);
            return new ContainerBody(inv, type, id, title, l, t, w, h, slots, carried);
        }
    }

    // ---------------------------------------------------------------- command block GUI
    /** mode: 0 = sequence (chain), 1 = auto (repeating), 2 = redstone (impulse) */
    record CommandBlockBody(String command, int mode, boolean conditional, boolean automatic) implements GuiBody {
        public int type() { return TYPE_COMMAND_BLOCK; }
        public String shapeKey() { return "cb"; }

        public void write(RegistryFriendlyByteBuf buf) {
            buf.writeUtf(command, 32767);
            buf.writeByte(mode);
            buf.writeBoolean(conditional);
            buf.writeBoolean(automatic);
        }

        static CommandBlockBody read(RegistryFriendlyByteBuf buf) {
            return new CommandBlockBody(buf.readUtf(32767), buf.readByte(), buf.readBoolean(), buf.readBoolean());
        }
    }

    // ---------------------------------------------------------------- 1.21.6+ dialogs
    /** The dialog encoded with Dialog.CODEC (as NBT) so it does not depend on the replay's registries. */
    record DialogBody(Tag dialogTag) implements GuiBody {
        public int type() { return TYPE_DIALOG; }
        public String shapeKey() { return "d|" + dialogTag.hashCode(); }

        public void write(RegistryFriendlyByteBuf buf) { buf.writeNbt(dialogTag); }

        static DialogBody read(RegistryFriendlyByteBuf buf) { return new DialogBody(buf.readNbt()); }
    }
}
