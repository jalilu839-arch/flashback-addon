package dev.flashguiplus.mixin;

import dev.flashguiplus.FlashGuiConfig;
import dev.flashguiplus.playback.GuiPlayback;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Screen.class)
public class MixinScreen {
    /** "Dim behind GUI" off -> skip the vanilla darkened/blurred background for our ghost screens only. */
    @Inject(method = "renderBackground", at = @At("HEAD"), cancellable = true)
    private void flashguiplus$noDim(GuiGraphics g, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        if (GuiPlayback.isRenderingGhost() && !FlashGuiConfig.get().dimBehind) ci.cancel();
    }
}
