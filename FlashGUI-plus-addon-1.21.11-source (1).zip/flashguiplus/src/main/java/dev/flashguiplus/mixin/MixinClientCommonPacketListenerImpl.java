package dev.flashguiplus.mixin;

import dev.flashguiplus.record.GuiRecorder;
import net.minecraft.client.multiplayer.ClientCommonPacketListenerImpl;
import net.minecraft.network.protocol.common.ClientboundShowDialogPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientCommonPacketListenerImpl.class)
public class MixinClientCommonPacketListenerImpl {
    /** Remember the dialog the server showed so GuiRecorder can write it while the DialogScreen is open. */
    @Inject(method = "handleShowDialog", at = @At("HEAD"), require = 0)
    private void flashguiplus$captureDialog(ClientboundShowDialogPacket packet, CallbackInfo ci) {
        GuiRecorder.lastDialog = packet.dialog();
    }
}
