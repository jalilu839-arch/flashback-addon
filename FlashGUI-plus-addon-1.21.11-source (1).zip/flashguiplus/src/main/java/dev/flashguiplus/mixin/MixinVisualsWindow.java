package dev.flashguiplus.mixin;

import com.moulberry.flashback.editor.ui.windows.VisualsWindow;
import dev.flashguiplus.ui.VisualsSection;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = VisualsWindow.class, remap = false)
public class MixinVisualsWindow {
    /**
     * VisualsWindow.render() draws two section headers with separatorWithText: #0 = "GUI", #1 = "World".
     * Injecting right before #1 puts the FlashGUI+ block between them, like in the video.
     */
    @Inject(method = "render", remap = false,
            at = @At(value = "INVOKE", remap = false, ordinal = 1,
                     target = "Lcom/moulberry/flashback/editor/ui/ImGuiHelper;separatorWithText(Ljava/lang/String;)V"))
    private static void flashguiplus$section(CallbackInfo ci) {
        VisualsSection.render();
    }
}
