package dev.flashguiplus;

import dev.flashguiplus.net.GuiStatePayload;
import dev.flashguiplus.playback.GuiPlayback;
import dev.flashguiplus.record.GuiRecorder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** FlashGUI+ : Flashback addon that records and replays open GUIs. */
public class FlashGuiPlus implements ClientModInitializer {
    public static final String ID = "flashguiplus";
    public static final Logger LOGGER = LoggerFactory.getLogger("FlashGUI+");

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(ID, path);
    }

    @Override
    public void onInitializeClient() {
        FlashGuiConfig.load();

        // The payload is written into the replay file as a normal clientbound play packet
        // (same trick Flashback uses for FlashbackRemoteSetSlot) and received again on playback.
        PayloadTypeRegistry.playS2C().register(GuiStatePayload.TYPE, GuiStatePayload.CODEC);
        ClientPlayNetworking.registerGlobalReceiver(GuiStatePayload.TYPE,
                (payload, context) -> GuiPlayback.accept(payload));

        ClientTickEvents.END_CLIENT_TICK.register(GuiRecorder::tick);
        HudElementRegistry.addLast(id("recorded_gui"), GuiPlayback::render);

        LOGGER.info("FlashGUI+ loaded");
    }
}
