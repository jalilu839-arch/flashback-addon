# FlashGUI+  (Flashback addon, Minecraft 1.21.11, Fabric)

Records the GUI you have open while Flashback records, and draws it again in the replay / export.

**Records + replays:** every container GUI (chest, ender chest, shulker, crafting table, furnace, anvil,
enchanting, hopper, dispenser… and the player inventory), the **command block GUI**, and **1.21.6+ dialogs**.
Anything without a vanilla screen to rebuild (creative inventory, modded menus) falls back to a generic slot panel.

**Visuals window → new "FlashGUI+" section** (between GUI and World), same options as the video:
Recorded GUI · Dim behind GUI · Recorded cursor · Show mouse pointer · Hitboxes · Debug screen (F3) · Record GUIs

## Build (needs Java 21)
1. Open https://fabricmc.net/develop, pick 1.21.11, and copy the loader / loom / Fabric API versions into `gradle.properties`.
2. `gradle build`  (or `./gradlew build` if you add the wrapper) → `build/libs/flashguiplus-1.0.0.jar`
3. Put that jar in `mods/` next to Flashback 0.39.10 and Fabric API.

No PC? Push this folder to a GitHub repo → Actions tab → "build" → download the artifact.

`libs/flashback-compile.jar` is a stripped copy of your Flashback jar (classes only) used just to compile. Don't publish it.

## Not compiled yet - expect small fixes
This was written without a Minecraft/JDK install, so names were checked against Flashback's real jar
(those parts are solid) but NOT against Minecraft 1.21.11. If the compiler or the first launch complains, it is
almost certainly one of these:
- `util/DebugToggles.java` – F3 / hitbox API (`debugEntries`, `DebugScreenEntries.ENTITY_HITBOXES`). Least certain.
- `playback/GhostScreens.java` – `DialogScreens.createFromData(...)`, `DialogConnectionAccess`, `RemotePlayer(...)` ctor.
- `record/GuiRecorder.java` – `Dialog.CODEC`, `DialogScreen`, `AbstractCommandBlockEditScreen`.
- mixin accessors – field names `commandEdit`, `mode`, `conditional`, `autoexec`, `leftPos/topPos/imageWidth/imageHeight`.
- `MixinClientCommonPacketListenerImpl` – method `handleShowDialog` (set `require = 0`, so a miss only disables dialogs).
- `FlashGuiPlus.java` – `HudElementRegistry.addLast` (older Fabric API: `HudRenderCallback.EVENT`).
- `ResourceLocation` was renamed `Identifier` in 1.21.11; if your mappings still say ResourceLocation, swap the imports.

## Known limits
- Typed text in anvil / sign / book screens, and minecart command blocks, are not recorded yet (add a case in `GuiRecorder.capture` + a `GuiBody` record).
- After seeking, the GUI can take up to 0.5 s to reappear (full state is re-written every 10 ticks).
- Replayed GUIs are display-only (no clicking).
